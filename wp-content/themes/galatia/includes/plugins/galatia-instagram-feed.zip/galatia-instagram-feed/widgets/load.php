<?php

include_once 'galatia-instagram-widget.php';