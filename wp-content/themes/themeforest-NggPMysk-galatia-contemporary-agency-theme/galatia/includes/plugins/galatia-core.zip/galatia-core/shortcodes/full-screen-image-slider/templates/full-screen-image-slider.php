<div class="edgtf-full-screen-image-slider <?php echo esc_attr($holder_classes); ?>">
	<div class="edgtf-fsis-slider edgtf-owl-slider" <?php echo galatia_edge_get_inline_attrs($slider_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
	<div class="edgtf-fsis-thumb-nav edgtf-fsis-prev-nav"></div>
	<div class="edgtf-fsis-thumb-nav edgtf-fsis-next-nav"></div>
	<div class="edgtf-fsis-slider-mask"></div>
</div>