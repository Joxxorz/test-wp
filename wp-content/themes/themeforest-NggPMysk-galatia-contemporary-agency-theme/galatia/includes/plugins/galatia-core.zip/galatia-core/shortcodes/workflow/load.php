<?php

include_once GALATIA_CORE_SHORTCODES_PATH . '/workflow/functions.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/workflow/workflow.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/workflow/workflow-item.php';