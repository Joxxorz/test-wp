<?php

include_once GALATIA_CORE_SHORTCODES_PATH . '/full-screen-spotlight-slider/functions.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/full-screen-spotlight-slider/full-screen-spotlight-slider.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/full-screen-spotlight-slider/full-screen-spotlight-slider-item.php';