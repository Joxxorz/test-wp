<div class="edgtf-clients-carousel-holder <?php echo esc_attr($holder_classes); ?>">
	<div class="edgtf-cc-inner edgtf-owl-slider" <?php echo galatia_edge_get_inline_attrs($carousel_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>