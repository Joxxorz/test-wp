<div class="edgtf-full-screeen-spotlight-slider-holder edgtf-full-screen-sections <?php echo esc_attr( $holder_classes ); ?>" <?php echo galatia_edge_get_inline_attrs( $holder_data ); ?>>
	<div class="edgtf-fss-wrapper">
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>