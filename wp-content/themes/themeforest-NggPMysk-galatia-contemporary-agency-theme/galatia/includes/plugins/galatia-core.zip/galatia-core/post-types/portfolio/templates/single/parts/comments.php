<?php if(galatia_edge_show_comments()) : ?>
    <?php comments_template('', true); ?>
<?php endif; ?>