<?php

include_once GALATIA_CORE_SHORTCODES_PATH . '/pricing-table/functions.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/pricing-table/pricing-table.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/pricing-table/pricing-table-item.php';