<?php

include_once GALATIA_CORE_SHORTCODES_PATH . '/cards-gallery/functions.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/cards-gallery/cards-gallery.php';