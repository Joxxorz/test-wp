<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR . '/title/types/standard/functions.php';