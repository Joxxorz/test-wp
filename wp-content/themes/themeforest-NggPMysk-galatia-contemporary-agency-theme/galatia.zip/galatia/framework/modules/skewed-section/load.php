<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/skewed-section/functions.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/skewed-section/helper-functions.php';

//load global skew section options
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/skewed-section/admin/options-map/skewed-section-map.php';

//load per page title options
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/skewed-section/admin/meta-boxes/skewed-section-meta-boxes.php';
