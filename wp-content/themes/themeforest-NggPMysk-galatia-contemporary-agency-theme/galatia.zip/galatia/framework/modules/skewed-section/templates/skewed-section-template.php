<div class="edgtf-skewed-section-effect <?php echo esc_attr( $additional_class ) ?>" <?php galatia_edge_inline_style( $skewed_section_effect_style ) ?>>
	<?php echo galatia_edge_get_module_part( $skewed_section_svg ); ?>
</div>