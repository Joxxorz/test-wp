<?php
if(galatia_edge_show_comments()){
    comments_template('', true);
}