<div class="edgtf-gutenb-title-holder">
    <div class="edgtf-gutenb-title-wrapper">
        <div class="edgtf-gutenb-title-inner">
            <div class="edgtf-grid">
                <?php if(!empty($title)) { ?>
                <<?php echo esc_attr($title_tag); ?> class="edgtf-page-title entry-title"><?php echo esc_html($title); ?></<?php echo esc_attr($title_tag); ?>>
            <?php } ?>
            </div>
        </div>
    </div>
</div>