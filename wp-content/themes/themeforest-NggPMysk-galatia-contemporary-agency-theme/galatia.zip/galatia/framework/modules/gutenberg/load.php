<?php
if ( galatia_edge_is_plugin_installed( 'gutenberg-editor' ) || galatia_edge_is_plugin_installed( 'gutenberg-plugin' ) ) {
	include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR . '/gutenberg/functions.php';
}
