<?php

include_once EDGE_FRAMEWORK_HEADER_ROOT_DIR . '/types/top-header/functions.php';