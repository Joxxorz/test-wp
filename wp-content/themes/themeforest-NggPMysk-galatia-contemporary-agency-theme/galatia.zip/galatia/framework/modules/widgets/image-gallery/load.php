<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/image-gallery/functions.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/image-gallery/image-gallery.php';