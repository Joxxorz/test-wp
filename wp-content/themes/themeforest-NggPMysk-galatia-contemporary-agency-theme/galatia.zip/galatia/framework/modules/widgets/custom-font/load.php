<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/custom-font/functions.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/custom-font/custom-font.php';