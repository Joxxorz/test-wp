<?php

do_action('galatia_edge_action_style_dynamic');